package online.afeibaili;

import com.fasterxml.jackson.databind.ObjectMapper;
import online.afeibaili.map.Address;
import online.afeibaili.map.Package;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;


public class Main {
    //JSON处理工具
    public static final ObjectMapper JSON = new ObjectMapper();

    public static void main(String[] args) throws URISyntaxException, IOException, InterruptedException {
        int roomId = 1947172740;
        String url = "https://api.live.bilibili.com/xlive/web-room/v1/index/getDanmuInfo?id=" + roomId + "&type=0";
        String cookie = "buvid3=3CBB5B30-0287-6B57-7BEA-D85704C877C307296infoc; b_nut=1737267108; _uuid=E10EF99E1-63BF-991C-EAE2-84D763365109360833infoc; header_theme_version=CLOSE; enable_web_push=DISABLE; fingerprint=477667d7ea060813ea99dac5396c9522; buvid_fp_plain=undefined; buvid4=28AAF91B-B0B4-A674-6290-78AF0F6A921589122-025010912-YdWyxxfOXPp1lFbXc2DbGAD6rTwyVCbBVtZXspRU%2Foezz06cQS98EuOFeG3zLTWr; rpdid=0zbfVFUl7d|139FU5ZKq|16|3w1TA9Wz; bili_ticket=eyJhbGciOiJIUzI1NiIsImtpZCI6InMwMyIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3Mzc4MjcxOTYsImlhdCI6MTczNzU2NzkzNiwicGx0IjotMX0.x8xiWgxpSoNMmfnvk48OZ6GtGLaS2OF5bf21TAcj-Ek; bili_ticket_expires=1737827136; CURRENT_FNVAL=4048; bsource=search_bing; enable_feed_channel=DISABLE; home_feed_column=5; LIVE_BUVID=AUTO9417376354675186; browser_resolution=1528-738; bp_t_offset_1017959664=1025635145152987136; SESSDATA=c3bbb836%2C1753189702%2Ce7a71%2A11CjCUTdPFsmB9YeaQQ9PAVMS1p33-9hTsVTuiUqx9z7pInsSuE6-lZIWUHAaUI9c_j7wSVkxsb3hHcmlZRkhVOVAwZWdzUWx4emF6a2E4SG5fWmVtdHhnRVlIdFlrLWxIdkJBQjdxSGF1RVhTV1NEVzllWnNRa2s2Q3EtSTRseG1qbkU4TlcyV3RRIIEC; bili_jct=d894860021a8cb86593546a657527028; DedeUserID=482342947; DedeUserID__ckMd5=f6bb78b22ce2e28c; sid=qe6ltbpz; bp_t_offset_482342947=1025657629306781696; Hm_lvt_8a6e55dbd2870f0f5bc9194cddf32a02=1737190500,1737645340; HMACCOUNT=28170D286B44D14E; Hm_lpvt_8a6e55dbd2870f0f5bc9194cddf32a02=1737646032; b_lsid=846CFBE3_19493C83AC7; buvid_fp=477667d7ea060813ea99dac5396c9522; PVID=14";

        //使用Util.getRoomAddressJson()方法获取地址，并使用readValue方法将JSON转成Address对象
        Address address = JSON.readValue(Util.getRoomAddressJson(url, roomId, cookie), Address.class);
        //获取地址主要信息
        int port = address.getData().getHostList().get(0).getWssPort();
        String host = address.getData().getHostList().get(0).getHost();
        String token = address.getData().getToken();

        //连接并发送心跳包
        URI uri = new URI("wss://" + host + ":" + port + "/sub");
        Package pkg = new Package(
                482342947,
                roomId,
                2,
                "3CBB5B30-0287-6B57-7BEA-D85704C877C307296infoc",
                "web",
                2,
                token);
        //创建鉴权包
        byte[] dataPackage = Package.createDataPackage(7, JSON.writeValueAsString(pkg).getBytes(StandardCharsets.UTF_8));
        //创建客户端
        WebSocketClient client = new WebSocketClient(uri, dataPackage);
        client.connect();
    }
}
