package online.afeibaili;

import cn.hutool.core.util.ZipUtil;
import online.afeibaili.map.Package;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Timer;
import java.util.TimerTask;

/**
 * 继承WebSocketClient
 */
public class WebSocketClient extends org.java_websocket.client.WebSocketClient {
    public byte[] pkg;
    public Timer timer = new Timer();   //定时器

    {
        //配置定时器
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                send(Package.createDataPackage(2, new byte[0]));
            }
        }, 30000, 30000);
    }

    public WebSocketClient(URI serverUri, byte[] pkg) {
        super(serverUri);
        this.pkg = pkg;
    }

    @Override
    public void onOpen(ServerHandshake handshakedata) {
        this.send(pkg);
        System.out.println("连接成功!");
    }

    @Override
    public void onMessage(String message) {

    }

    @Override
    public void onMessage(ByteBuffer bytes) {
        unpack(bytes);
    }

    @Override
    public void onClose(int code, String reason, boolean remote) {
        timer.cancel();
        System.out.println("onClose: " + reason);
    }

    @Override
    public void onError(Exception ex) {
        System.out.println(ex.getMessage());
    }

    /**
     * 解发送过来的包
     *
     * @param byteBuffer 字节缓存
     */
    public static void unpack(ByteBuffer byteBuffer) {
        int packageLen = byteBuffer.getInt();
        short headLength = byteBuffer.getShort();
        short packageVer = byteBuffer.getShort();
        int optCode = byteBuffer.getInt();
        int sequence = byteBuffer.getInt();
        if (2 == optCode) {
            System.out.println("这是服务器心跳回复");
        }
        byte[] contentBytes = new byte[packageLen - headLength];
        byteBuffer.get(contentBytes);
        //如果是zip包就进行解包
        if (2 == packageVer) {
            unpack(ByteBuffer.wrap(ZipUtil.unZlib(contentBytes)));
            return;
        }

        String content = new String(contentBytes, StandardCharsets.UTF_8);
        if (8 == optCode) {
            System.out.println("这是鉴权回复：" + content);
        }
        if (5 == optCode) {
            System.out.println("真正的弹幕消息：" + content);
            // todo 自定义处理

        }
        if (byteBuffer.position() < byteBuffer.limit()) {
            unpack(byteBuffer);
        }
    }
}
